
struct colr_data {
    int red, green, blue;
};

extern void MedianInit();
extern void MedianCount();
extern void MedianSplit();
extern void ConvertColor();
